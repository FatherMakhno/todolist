<script setup>
</script>

<template>
  <h1>todolist</h1>
  <div class="main">
    <router-view></router-view>
  </div>
  
</template>

<style lang="scss" scoped>
.main {
  padding: 20px;
  background: white;
  min-height: 80vh;
  border-radius: 10px;
}
</style>
